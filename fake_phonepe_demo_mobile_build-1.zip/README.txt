FAKE PHONEPE DEMO — FLUTTER SOURCE

This is a clearly labeled local payment simulator. It does not connect to PhonePe,
UPI, banks, or payment networks. It cannot send or receive money.

BUILD USING YOUR ANDROID PHONE:
1. Create a NEW GitHub repository for this demo.
2. Extract this ZIP and upload all files and folders, including the hidden .github folder.
3. Open the repository's Actions tab.
4. Select "Build Android demo APK" and tap "Run workflow" (or wait for the push build).
5. Open the completed workflow run and download artifact "fake-phonepe-demo-apk".
6. Extract that artifact ZIP to get app-release.apk, then install it.

The app and every receipt clearly say DEMO / NOT A REAL PAYMENT.
